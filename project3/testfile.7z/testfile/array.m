let mut a[int, 10];
fn main() 
{
    a[3] = 20;
    a[8] = 38;
    print a[3];
    println a[8];
}
