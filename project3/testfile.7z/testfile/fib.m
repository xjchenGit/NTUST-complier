(* fib.modula
 *
 * This test program computes the Nth Fibonacci number
 *)

module fib

    // variables
    var n, Fn, FNminus1, temp: integer;

begin
    // variable initialization
    n := 8;
    Fn := 1;
    FNminus1 := 1;
    
    // compute the nth Fibonacci number
    while (n > 2) do
      temp := Fn;
      Fn := Fn + FNminus1;
      FNminus1 := temp;
      n := n - 1;
    end;
    
    // print result
    print "Result of computation: ";
    println n;
end fib.
