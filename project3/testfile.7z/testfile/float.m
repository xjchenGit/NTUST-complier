// let mut pi = 3.14;
// let mut ans = 2.01;
// fn main() 
// {
//    ans  = pi * 2;
//    println ans;
// }

module FLO
var a,b:real;
begin
   a:=1.1;
   b:=2.1;
   a:=a*b;
   println a;
end FLO.
