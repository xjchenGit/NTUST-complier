(* Hello World Example *)
module HelloWorld
begin
  // Print text to the console
  print ("Hello World");
end HelloWorld.
