// let a = "Hello, How Are You!!!";
// fn main() 
// {
//     println a;
// }

module STRE
var a:string;
begin
    a:="Hello, How Are You!!!";
    println a;
end STRE.