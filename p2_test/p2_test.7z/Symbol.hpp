#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;

struct DataItem{
    string IdName = " ";
    string type = " ";
    string value = " ";
    string entries = " ";
};

class SymbolTable{
public:
    DataItem* lookup(string s);
    bool insert(string s,DataItem value);
    int Dump();
private:
    map<string,DataItem> IdSymbols;
};

DataItem* SymbolTable::lookup(string s){
    if (IdSymbols.count(s))
    {
        cout << "find it!"<< endl;
        return new DataItem(IdSymbols[s]);
    }
    else
    {
        return NULL;
        cout << "Not found!" << endl;
    }
        
}

bool SymbolTable::insert(string s,DataItem value)
{
    if (!IdSymbols.count(s))
    {
        IdSymbols[s]=value;
        return true;
    }else
    {
        return false;
    }
}

int SymbolTable::Dump(){
    for(auto it = IdSymbols.begin();it != IdSymbols.end();++it)
    {
        cout
        << it->second.IdName <<"\t"
        << it->second.type <<"\t"
        << it->second.value <<"\t\t"
        << it->second.entries <<"\t"
        << endl;
    }
    cout<<("\n--------------------------------------------\n");
    return IdSymbols.size();
}


// int main(){
//     vector<SymbolTable> stack;
//     SymbolTable global;
//     SymbolTable local;

//     struct DataItem IdData;
//     struct DataItem IdData2;
//     struct DataItem IdData3;
//     stack.push_back(global);
//     stack.push_back(local);
//     string s="ABC";
//     IdData.IdName="ABC";
//     IdData.type="const";
//     IdData.value="126789";
//     IdData.entries="assginment";

//     string s2="DEF";
//     IdData2.IdName="DEF";
//     IdData2.type="integer";
//     IdData2.value="95645";
//     IdData2.entries="function";

//     string s3="JKL";
//     IdData3.IdName="UIO";
//     IdData3.type="REAL";
//     IdData3.value="131443";
//     IdData3.entries="assgin";

//     bool a=stack[0].insert(s,IdData);
//     bool c=stack[0].insert(s3,IdData3);
//     bool b=stack[1].insert(s2,IdData2);
//     if(a&&b&&c)
//     {
//         cout << "successed!!"<< endl;
//         cout << stack[0].Dump() <<endl;
//         cout << stack[1].Dump() <<endl;
//     }else
//         cout << "failed!!" << endl;
//     // stack.pop_back();
//     // int d=stack.size();
//     // cout << "what is the size of stack" << d << endl;

//     string s4="ABC";
//     stack[0].lookup(s4);

//     return 0;
// }